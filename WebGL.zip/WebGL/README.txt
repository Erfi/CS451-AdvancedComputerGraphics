HTML: contains the main HTML files. These are the ones that you run on your browser.
	Use Safari for the ones which have texture mapping. (Change the Safari settings to 	enable WebGl and Disable Local File Restriction)

CSS: CSS files for each HTML.

IMAGES: Contains texture maps borrowed from minecraft!

JS -> src: Contains the javascript files for each HTML.

JS -> lib: Contains libraries such as three.js and dat.gui.js. The rest of the library f	iles were not used for this project. 